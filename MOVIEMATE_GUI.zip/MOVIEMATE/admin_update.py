import streamlit as st
from writedb import writedb  # Ensure correct import based on your setup
from datetime import datetime

# Initialize database connection (adjust parameters as needed)
db = writedb(verbose=True)

def update_movie_description(movie_id, new_description):
    update_query = "UPDATE Movie SET Description = ? WHERE Movie_ID = ?"
    return db.execute(update_query, (new_description, movie_id), inserted=True)

def update_showtime(movie_id, screen_id, old_showtime, new_showtime):
    update_query = "UPDATE Show SET ShowTime = ? WHERE Movie_ID = ? AND Screen_ID = ? AND ShowTime = ?"
    return db.execute(update_query, (new_showtime, movie_id, screen_id, old_showtime),inserted=True)
def update_showtime_by_show_id(show_id, new_showtime):
    """
    Update the showtime of a show based on its Show_ID.

    :param show_id: The ID of the show to update.
    :param new_showtime: The new showtime to set.
    :return: True if the update was successful, False otherwise.
    """
    update_query = "UPDATE Show SET ShowTime = ? WHERE Show_ID = ?"
    return db.execute(update_query, (new_showtime, show_id), inserted=True)

def update_show():
    st.title("Admin Panel - Update Movie Details")

    # Update movie description section
    st.header("Update Movie Description")
    _, movies_list = db.execute("SELECT Movie_ID, Title FROM Movie")
    movie_options = ["Select a movie"] + [f"{movie[1]} (ID: {movie[0]})" for movie in movies_list]
    selected_movie = st.selectbox("Choose a movie to update its description:", movie_options)

    if selected_movie != "Select a movie":
        movie_id = selected_movie.split(" (ID: ")[1].rstrip(")")
        _, current_description = db.execute("SELECT Description FROM Movie WHERE Movie_ID = ?", (movie_id,))
        st.text(f"Current Description: {current_description[0][0]}")
        new_description = st.text_area("New Description:")

        if st.button("Update Description"):
            if update_movie_description(movie_id, new_description):
                st.success("Movie description updated successfully.")
            else:
                st.error("Failed to update movie description.")

    # Update showtime section
    st.header("Update Showtime")
    # selected_movie_for_showtime = st.selectbox("Choose a movie to update its showtime:", movie_options, key="showtime")

    # if selected_movie_for_showtime != "Select a movie":
    #     movie_id = selected_movie_for_showtime.split(" (ID: ")[1].rstrip(")")
    #     _, screen_list = db.execute("SELECT DISTINCT Screen_ID FROM Show WHERE Movie_ID = ?", (movie_id,))
    #     screen_options = ["Select a screen"] + [str(screen[0]) for screen in screen_list]
    #     selected_screen = st.selectbox("Choose a screen:", screen_options)

    #     if selected_screen != "Select a screen":
    #         _, showtimes = db.execute("SELECT ShowTime FROM Show WHERE Movie_ID = ? AND Screen_ID = ?", (movie_id, selected_screen))
    #         showtime_options = ["Select a showtime"] + [str(showtime[0]) for showtime in showtimes]
    #         selected_showtime = st.selectbox("Choose a showtime to update:", showtime_options)

    #         new_showtime = st.time_input("New Showtime:")

    #         if st.button("Update Showtime"):
    #             if update_showtime(movie_id, selected_screen, selected_showtime, new_showtime.strftime("%H:%M:%S")):
    #                 st.success("Showtime updated successfully.")
    #             else:
    #                 st.error("Failed to update showtime.")


    # Fetch theatres and prepare options
    _, theatres_list = db.execute("SELECT Theatre_ID, Name FROM Theatre")
    theatre_options = ["Select a theatre"] + [f"{theatre[1]} (ID: {theatre[0]})" for theatre in theatres_list]
    selected_theatre = st.selectbox("Choose a theatre:", theatre_options)

    if selected_theatre != "Select a theatre":
        theatre_id = selected_theatre.split(" (ID: ")[1].rstrip(")")
        
        # Fetch screens within the selected theatre
        _, screen_list = db.execute("SELECT Screen_ID, Name FROM Screen WHERE Theatre_ID = ?", (theatre_id,))
        screen_options = ["Select a screen"] + [f"{screen[1]} (ID: {screen[0]})" for screen in screen_list]
        selected_screen = st.selectbox("Choose a screen:", screen_options)

        if selected_screen != "Select a screen":
            screen_id = selected_screen.split(" (ID: ")[1].rstrip(")")
            
            # Fetch shows scheduled on the selected screen
            _, show_list = db.execute("""
                SELECT Show.Show_ID, Movie.Title, Show.ShowTime 
                FROM Show 
                INNER JOIN Screening ON Show.Show_ID = Screening.Show_ID 
                INNER JOIN Movie ON Show.Movie_ID = Movie.Movie_ID 
                WHERE Screening.Screen_ID = ?""", (screen_id,))
            show_options = ["Select a show"] + [f"{show[1]} at {show[2]} (ID: {show[0]})" for show in show_list]
            selected_show = st.selectbox("Choose a show to update its showtime:", show_options)

            if selected_show != "Select a show":
                show_id = selected_show.split(" (ID: ")[1].split(")")[0]
                
                new_showtime = st.time_input("New Showtime:")
                
                if st.button("Update Showtime"):
                    # Function to update showtime needs to be adapted for this setup
                    if update_showtime_by_show_id(show_id, new_showtime.strftime("%H:%M:%S")):
                        st.success("Showtime updated successfully.")
                    else:
                        st.error("Failed to update showtime.")
