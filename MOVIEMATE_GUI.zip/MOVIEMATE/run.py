import subprocess

def run_streamlit_app(file, port):
    subprocess.Popen(["streamlit", "run", file, "--server.port", str(port)])

# Paths to your Streamlit files
main_app = 'main.py'
admin_app = 'admin.py'

# Ports
main_port = 8503
admin_port = 8502  

# Run the apps
run_streamlit_app(main_app, main_port)
run_streamlit_app(admin_app, admin_port)
