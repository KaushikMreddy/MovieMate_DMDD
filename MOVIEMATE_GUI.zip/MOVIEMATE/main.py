import streamlit as st
from writedb import writedb  # Make sure this is correctly importing your DB class
import utils  # Assuming utils contains necessary utility functions like credit card validation

# Initialize database connection
writedb = writedb(verbose=True)  # Updated to the correct database name

def cust_id():
    _, data = writedb.execute('SELECT MAX(Customer_ID) FROM Customer')
    if data:
        cust_id = data[0][0] + 1
    else:
        cust_id = 1
    return cust_id

def next_booking_id():
    _, data = writedb.execute('SELECT MAX(Booking_ID) FROM Booking')
    return data[0][0] + 1 if data and data[0][0] is not None else 1

def next_payment_id():
    _, data = writedb.execute('SELECT MAX(Payment_ID) FROM Payment')
    return data[0][0] + 1 if data and data[0][0] is not None else 1

def curr_bookid():
    _, data = writedb.execute('SELECT MAX(Booking_ID) FROM Booking')
    return data[0][0] if data and data[0][0] is not None else 1

def update_seat_availability(show_id, seat_ids):
    # Update the isAvailable status for each selected seat
    for seat_id in seat_ids:
        update_query = "UPDATE Seat SET isAvailable = 0 WHERE Show_ID = ? AND Seat_ID = ?"
        _, _ = writedb.execute(update_query, (show_id, seat_id),inserted=True)


st.title("MovieMate-Movie Ticket Reservation")

# Initialize session state variables
if 'submitted' not in st.session_state:
    st.session_state['submitted'] = False
if 'confirm_booking' not in st.session_state:
    st.session_state['confirm_booking'] = False

_, movies_list = writedb.execute('SELECT Title FROM Movie')

# Create a dropdown menu with "Select Movie" as the default option
selected_movie = st.selectbox("Choose a Movie", options=["Select Movie"] + [movie[0] for movie in movies_list])

if selected_movie != "Select Movie":
    _, desc = writedb.execute(f"SELECT Description FROM Movie WHERE Title = ?", (selected_movie,))
    st.text(f"Description: {desc[0][0]}")
    _, dates = writedb.execute("SELECT DISTINCT Show_Date FROM Show JOIN Movie ON Show.Movie_ID = Movie.Movie_ID WHERE Show_Date >= CAST(GETDATE() AS DATE) AND Title = ?", (selected_movie,))
    selected_date = st.selectbox("Choose a Date", options=["Select Date"] + [date[0] for date in dates])

    if selected_date != "Select Date":
        # Using stored procedure to get screening details
        _, screenings = writedb.execute("EXEC GetMovieScreeningDetails ?", (selected_movie,), SP=True)
        screenings = [s for s in screenings if s[1] == selected_date]  # Filter by selected date
        if screenings:
            screening_options = []
            for screens in screenings:
                screening_options.append(screens[3])
            selected_theater = st.selectbox("Choose a Theatre", options=["Select Theatre"] + screening_options)
            if selected_theater != "Select Theatre":
                # Fetch show times and their corresponding Show_IDs for the selected movie and date
                _, shows = writedb.execute("""
                    SELECT Show_ID, ShowTime
                    FROM Show
                    JOIN Movie ON Show.Movie_ID = Movie.Movie_ID
                    WHERE Movie.Title = ? AND Show.Show_Date = ?
                """, (selected_movie, selected_date))

                if shows:
                    # Creating a dictionary to map show times to their Show_IDs
                    show_dict = {show[1]: show[0] for show in shows}
                    selected_show_time = st.selectbox("Choose a Show Time", options=["Select Show Time"] + list(show_dict.keys()))

                    if selected_show_time != "Select Show Time":
                        selected_show_id = show_dict[selected_show_time]  # Get the Show_ID corresponding to the selected show time
                        st.text(f"Selected Show Time: {selected_show_time}, Show ID: {selected_show_id}")

                        # Now you can use selected_show_id for further queries, like fetching seat types
                        _, seat_types = writedb.execute("SELECT DISTINCT Type FROM Seat WHERE Show_ID = ?", (selected_show_id,))
                        selected_seat_type = st.selectbox("Select Seat Type", ["Select Type"] + [seat_type[0] for seat_type in seat_types])

                        if selected_seat_type != "Select Type":
                            # Fetch available seats based on selected type
                            _, available_seats = writedb.execute("SELECT Seat_ID FROM Seat WHERE Show_ID = ? AND Type = ? AND isAvailable = 1", (selected_show_id, selected_seat_type))
                            selected_seats = st.multiselect("Select Seats(max 4)", [seat[0] for seat in available_seats], max_selections=4)

                            if selected_seats:
                                seat_ids_placeholder = ','.join(['?']*len(selected_seats))  # Creates a placeholder string like "?,?,?,..."
                                query = f"SELECT SUM(Seat_Cost) FROM Seat WHERE Show_ID = ? AND Seat_ID IN ({seat_ids_placeholder})"

                                # Execute the query with the selected show ID and seat IDs
                                _, seat_costs = writedb.execute(query, [selected_show_id] + selected_seats)
                                
                                if seat_costs and seat_costs[0][0] is not None:
                                    total_seat_cost = seat_costs[0][0]
                                    st.text(f'The total price would be ${total_seat_cost}')
                                else:
                                    st.error("Unable to retrieve seat costs. Please try again.")

                                st.subheader("Customer Details")
                                customer_name = st.text_input("Full Name", key="cust_name")
                                customer_email = st.text_input("Email", key="cust_email")
                                customer_phone = st.text_input("Phone Number", key="cust_phone")
                                    
                                if  customer_name and  customer_email and  customer_phone and st.button("Submit Booking"):
                                    customer_id = cust_id()
                                    writedb.execute("INSERT INTO Customer (Customer_ID, Name, Email, Phone) VALUES (?, ?, ?, ?)", (customer_id, customer_name, customer_email, customer_phone), inserted=True)
                                    booking_id = next_booking_id()
                                    
                                    print(f"kjskdjksd : {booking_id}")
                                    # booking_id = ...  # Logic to generate or retrieve Booking_ID
                                    writedb.execute("INSERT INTO Booking (Booking_ID, Customer_ID, Show_ID, NumberOfSeats, Status) VALUES (?, ?, ?, ?, 'Confirmed')", (booking_id, customer_id, selected_show_id, len(selected_seats)),inserted=True)
                                    st.session_state['submitted'] = True
                                    # Payment Section
                                if st.session_state["submitted"]:
                                    st.subheader("Payment Details")
                                    account_number = st.text_input("Account Number", key="acc_num")
                                    payment_method = st.selectbox("Payment Method", ["Credit Card", "Debit Card", "GPay", "Applepay"], key="pay_method")
                                    st.session_state['confirm_booking'] = True
                                if st.session_state['confirm_booking']:
                                    new_book = curr_bookid()
                                    
                                    if st.button("Confirm Payment", key="confirm_pay"):
                                        payment_id = next_payment_id()  # Logic to generate or retrieve Payment_ID
                                        writedb.execute("INSERT INTO Payment (Payment_ID, Booking_ID, Account_Number, Amount, PaymentMethod) VALUES (?, ?, ?, ?, ?)", (payment_id, new_book, account_number, total_seat_cost, payment_method), inserted=True)
                                        update_seat_availability(selected_show_id, selected_seats)
                                        st.success("Booking and Payment Confirmed")