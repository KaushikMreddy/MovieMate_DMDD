import streamlit as st
from writedb import writedb
import mysql.connector as mdb
import utils 
from admin_delete import del_show
from admin_update import update_show

writedb = writedb(verbose=True)

st.set_page_config(page_title="Admin Dashboard", layout="wide")
    
    
option = st.sidebar.selectbox("Choose an option", ["Update Movies", "Delete showtimes"])
if option == "Delete showtimes":
    del_show()
elif option == "Update Movies":
    update_show()
