

import streamlit as st
from writedb import writedb  # Ensure this import matches your database connection setup

# Initialize database connection
db = writedb(verbose=True)

def delete_showtime(show_id, screen_id):
    """
    Delete a showtime and its related screening record, considering the composite primary key.
    """
    db.execute("DELETE FROM Seat WHERE Show_ID = ?", (show_id,),inserted=True)
    # First, delete related records in the Screening table
    db.execute("DELETE FROM Screening WHERE Show_ID = ? AND Screen_ID = ?", (show_id, screen_id),inserted=True)

    # Then, delete the showtime from the Show table
    db.execute("DELETE FROM Show WHERE Show_ID = ?", (show_id,),inserted=True)

    return True  # Adjust based on your db.execute method's return value

# Streamlit UI for the deletion process
def del_show():
    st.title("Delete Showtime")

    # Step 1: Select a Movie
    _, movies = db.execute("SELECT Movie_ID, Title FROM Movie")
    movie_options = ["Select a movie"] + [f"{title} (ID: {movie_id})" for movie_id, title in movies]
    selected_movie = st.selectbox("Select a Movie:", movie_options)

    if selected_movie != "Select a movie":
        movie_id = selected_movie.split(" (ID: ")[1].rstrip(")")

        # Step 2: Select a Theatre
        _, theatres = db.execute("""
            SELECT DISTINCT Theatre.Theatre_ID, Theatre.Name
            FROM Theatre
            INNER JOIN Screen ON Theatre.Theatre_ID = Screen.Theatre_ID
            INNER JOIN Screening ON Screen.Screen_ID = Screening.Screen_ID
            INNER JOIN Show ON Screening.Show_ID = Show.Show_ID
            WHERE Show.Movie_ID = ?
        """, (movie_id,))
        theatre_options = ["Select a theatre"] + [f"{name} (ID: {theatre_id})" for theatre_id, name in theatres]
        selected_theatre = st.selectbox("Select a Theatre:", theatre_options)

        if selected_theatre != "Select a theatre":
            theatre_id = selected_theatre.split(" (ID: ")[1].rstrip(")")

            # Step 3: Select a Screen
            _, screens = db.execute("""
                SELECT DISTINCT Screen.Screen_ID, Screen.Name
                FROM Screen
                INNER JOIN Screening ON Screen.Screen_ID = Screening.Screen_ID
                INNER JOIN Show ON Screening.Show_ID = Show.Show_ID
                WHERE Show.Movie_ID = ? AND Screen.Theatre_ID = ?
            """, (movie_id, theatre_id))
            screen_options = ["Select a screen"] + [f"{name} (ID: {screen_id})" for screen_id, name in screens]
            selected_screen = st.selectbox("Select a Screen:", screen_options)

            if selected_screen != "Select a screen":
                screen_id = selected_screen.split(" (ID: ")[1].rstrip(")")

                # Step 4: Select a Showtime
                _, showtimes = db.execute("""
                    SELECT Show.Show_ID, Show.ShowTime
                    FROM Show
                    INNER JOIN Screening ON Show.Show_ID = Screening.Show_ID
                    WHERE Show.Movie_ID = ? AND Screening.Screen_ID = ?
                """, (movie_id, screen_id))
                showtime_options = ["Select a showtime"] + [f"{showtime} (ID: {show_id})" for show_id, showtime in showtimes]
                selected_showtime = st.selectbox("Select a Showtime:", showtime_options)

                if selected_showtime != "Select a showtime":
                    show_id = selected_showtime.split(" (ID: ")[1].rstrip(")")

                    if st.button("Delete Showtime"):
                        if delete_showtime(show_id, screen_id):
                            st.success("Showtime and corresponding screening record deleted successfully.")
                        else:
                            st.error("Failed to delete showtime.")
