import pyodbc
import sys

# Assuming `utils.py` contains the definition of `bgcolors`
from utils import bgcolors

# Connection details for SQL Server
GLOBAL_HOST = '.'
GLOBAL_USER = 'team16'
GLOBAL_PWD = 'Damg@6210'
DATABASE_NAME = 'MovieMate3'

class writedb:
    def __init__(self, host=GLOBAL_HOST, user=GLOBAL_USER, password=GLOBAL_PWD, verbose=False):
        self.DB_HOST = host
        self.DB_USER = user
        self.DB_PWD = password
        self.DB_NAME = DATABASE_NAME
        self.DB_SUCCESS = False
        self.VERBOSE = verbose

        # Attempt to test the server connection
        if not self.test_server():
            print(bgcolors.FAIL + bgcolors.BOLD + "ERROR: Cannot access SQL Server\n" + bgcolors.ENDC)
            self.DB_SUCCESS = False
        else:
            self.DB_SUCCESS = True

    def execute(self, command, data=None, db_exists=True, SP=False, inserted = False):
        # Connection string for SQL Server
        # conn_str = (
        #     f'DRIVER={{SQL Server}};'
        #     f'SERVER={{DESKTOP-VQLHPTM}};'
        #     f'DATABASE={self.DB_NAME};'
        #     f'UID={self.DB_USER};'
        #     f'PWD={self.DB_PWD}'
        # )
        conn_str = (
    f'DRIVER=SQL Server;'
    f'SERVER=DESKTOP-VQLHPTM;'
    f'DATABASE={self.DB_NAME};'
        )
        if not db_exists:
            conn_str = conn_str.replace(f'DATABASE={self.DB_NAME};', '')

        # Connect to the database server
        db = pyodbc.connect(conn_str)
        cursor = db.cursor()

        # Execute the command
        ret = False
        results = []
        try:
            if data is None:
                print("lala")
                cursor.execute(command)
            else:
                # print("papa")
                cursor.execute(command, data)
            if not SP and not inserted:
                results = cursor.fetchall()
                # results_pp = [result[0] for result in results]
                # results = results_pp
            elif SP:
                results = cursor.fetchall()
            elif inserted:
                results = 0



            # Commit changes if needed
            db.commit()
            ret = True

        except pyodbc.Error as e:
            print(f"Database error: {e}")
            ret = False
        finally:
            # Close the database connection
            db.close()
        
        return ret, results

    def test_server(self):
        try:
            # Check the version of the server to ensure connection works
            ret, results = self.execute("SELECT @@VERSION", db_exists=False)
            if self.VERBOSE and results:
                print("SQL Server version:", results[0][0])
            return True
        except Exception as e:
            print(e)
            return False

    # ... (other methods remain unchanged) ...

# Main execution logic
if __name__ == "__main__":
    # Instantiate the database writer class
    db_writer = writedb(verbose=True)

    # Test the connection by executing a simple SELECT statement
    if db_writer.DB_SUCCESS:
        print("Connection to the SQL Server established successfully.")
        
        # Example usage: Retrieve all customers
        success, screenings = db_writer.execute("EXEC GetMovieScreeningDetails ?", ("Inception",), SP=True)
        if success:
            for customer in screenings:
                print(customer)
        else:
            print("Failed to retrieve customers.")
